import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buoi1',
  templateUrl: './buoi1.component.html',
  styleUrls: ['./buoi1.component.scss']
})
export class Buoi1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
