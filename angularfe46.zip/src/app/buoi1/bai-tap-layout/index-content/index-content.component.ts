import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-index-content',
  templateUrl: './index-content.component.html',
  styleUrls: ['./index-content.component.scss']
})
export class IndexContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
