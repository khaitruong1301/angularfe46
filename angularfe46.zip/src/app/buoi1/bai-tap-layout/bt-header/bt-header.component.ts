import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bt-header',
  templateUrl: './bt-header.component.html',
  styleUrls: ['./bt-header.component.scss']
})
export class BtHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
