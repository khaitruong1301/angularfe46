import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bai-tap-layout',
  templateUrl: './bai-tap-layout.component.html',
  styleUrls: ['./bai-tap-layout.component.scss']
})
export class BaiTapLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
